import json, numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import LineChart, Reference
from openpyxl.chart.series import SeriesLabel
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.utils import get_column_letter as L
O='/mnt/user-data/outputs'; U='/mnt/user-data/uploads'
d=json.load(open(f'{O}/model.json')); M=d['model']
FN='Arial'
f_=lambda **k: Font(name=FN,size=k.pop('size',10),**k)
HDR=PatternFill('solid',fgColor='2F5D45'); INP=PatternFill('solid',fgColor='FFF2CC'); GREY=PatternFill('solid',fgColor='F2F2F2')
thin=Side(style='thin',color='BFBFBF'); BOX=Border(left=thin,right=thin,top=thin,bottom=thin)
def hdr(ws,row,vals,col=1):
    for i,v in enumerate(vals):
        c=ws.cell(row,col+i,v); c.font=f_(bold=True,color='FFFFFF'); c.fill=HDR; c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
def style_all(ws):
    for row in ws.iter_rows():
        for c in row:
            if c.font.name!=FN: c.font=f_(bold=c.font.bold,color=c.font.color,italic=c.font.italic,size=c.font.size or 10)
wb=Workbook()
NAMES={'pea':'Pea','turnip_rape':'Turnip rape','carrot':'Carrot','potato':'Potato','spinach':'Spinach'}
RN={'FI_SW':'Finland SW','SE_SKANE':'Sweden Skåne'}
# ---------- Projections ----------
P=pd.DataFrame(d['rows']); 
P['key']=P.region+'|'+P.crop
P['base']=P.key.map(d['hist_baseline'])
def ext(r):
    m=M[r.key]; return int(any(x>m['hi'][i] or x<m['lo'][i] for i,x in enumerate(r.f)))
P['ext']=P.apply(ext,axis=1)
P=P.sort_values(['region','crop','scenario','year']).reset_index(drop=True)
wp=wb.active; wp.title='Projections'
cols=['Region','Crop','Scenario','Year','Yield t/ha','Baseline 2012–26 t/ha','Change vs baseline','Outside training weather (1=yes)','Growing-season mean temp °C','Growing-season water balance mm','Hot days (≥27 °C)']
hdr(wp,1,cols)
for i,r in P.iterrows():
    n=i+2
    wp.append([r.region,r.crop,r.scenario,int(r.year),round(r.yield_t_ha,3),round(r.base,3),f'=E{n}/F{n}-1',int(r.ext),round(r.f[0],2),round(r.f[1],0),round(r.f[2],1)])
NP=len(P)+1
for rr in wp.iter_rows(min_row=2,max_row=NP):
    rr[4].number_format='0.00'; rr[5].number_format='0.00'; rr[6].number_format='0.0%'
wp.freeze_panes='A2'; wp.auto_filter.ref=f'A1:K{NP}'
for i,w in enumerate([12,13,10,7,11,14,12,16,16,16,12],1): wp.column_dimensions[L(i)].width=w
wp.row_dimensions[1].height=42
# ---------- Features ----------
wf=wb.create_sheet('Features')
hdr(wf,1,['Key','Region','Scenario','Year','Mean temp °C','Water balance mm','Hot days','Precip mm'])
F=pd.DataFrame(d['rows'])[['region','scenario','year','f','precip']].drop_duplicates(['region','scenario','year']).sort_values(['region','scenario','year'])
for i,r in enumerate(F.itertuples(),2):
    wf.append([f'=B{i}&"|"&C{i}&"|"&D{i}',r.region,r.scenario,int(r.year),round(r.f[0],3),round(r.f[1],2),round(r.f[2],2),round(r.precip,1)])
NF=len(F)+1; wf.freeze_panes='A2'
for i,w in enumerate([26,12,10,7,13,15,10,10],1): wf.column_dimensions[L(i)].width=w
# ---------- Model ----------
wm=wb.create_sheet('Model')
hdr(wm,1,['Key (region|crop)','b0','b temp','b water bal','b hot days','mean temp','mean wbal','mean hot','sd temp','sd wbal','sd hot','smear','lo temp','lo wbal','lo hot','hi temp','hi wbal','hi hot','Backtest R² (log yield)','Training rows','Seasons','Baseline t/ha'])
for i,(k,m) in enumerate(sorted(M.items()),2):
    wm.append([k,m['b0'],*m['b'],*m['mu'],*m['sd'],m['smear'],*m['lo'],*m['hi'],round(m['cv_r2'],3),m['n'],m['years'],round(d['hist_baseline'][k],3)])
NM=len(M)+1
wm.cell(NM+2,1,'Yield = EXP(b0 + Σ b·(x − mean)/sd) × smear, with x = May–Sep mean temperature, water balance (precip − PET) and hot days. Trained on 2012–2026 survey yields; backtest R² is leave-one-year-out.').font=f_(italic=True)
wm.column_dimensions['A'].width=22
wm.freeze_panes='B2'
# ---------- Explorer ----------
we=wb.create_sheet('Explorer',0)
we['A1']='Scenario explorer – yield t/ha'; we['A1'].font=f_(bold=True,size=14)
we['A2']='Change the yellow cells. Everything else recalculates. Yields only – no prices.'; we['A2'].font=f_(italic=True,color='595959')
for r,(lab,val,fmt) in enumerate([('Region','FI_SW',None),('Crop','pea',None),('Extra warming (°C)',0,'0.0'),('Precipitation change (%)',0,'0')],3):
    we.cell(r,1,lab).font=f_(bold=True); c=we.cell(r,2,val); c.font=f_(color='0000FF',bold=True); c.fill=INP; c.border=BOX
    if fmt: c.number_format=fmt
dv1=DataValidation(type='list',formula1='"FI_SW,SE_SKANE"'); dv2=DataValidation(type='list',formula1='"pea,turnip_rape,carrot,potato,spinach"')
dv3=DataValidation(type='decimal',operator='between',formula1='-2',formula2='6'); dv4=DataValidation(type='decimal',operator='between',formula1='-30',formula2='30')
for dv,cell in [(dv1,'B3'),(dv2,'B4'),(dv3,'B5'),(dv4,'B6')]: we.add_data_validation(dv); dv.add(cell)
we['A8']='Model row'; we['B8']=f'=MATCH(B3&"|"&B4,Model!$A$2:$A${NM},0)'
we['A9']='Status'; we['B9']='=IF(ISNA(B8),"No yield model for this region/crop (no data)",IF(INDEX(Model!$S$2:$S$%d,B8)<0.05,"Weather explains little of this crop\'s yield – differences are weak","OK"))'%NM
we['A10']='Backtest R²'; we['B10']=f'=IFERROR(INDEX(Model!$S$2:$S${NM},B8),NA())'; we['B10'].number_format='0.00'
for r in (8,9,10): we.cell(r,1).font=f_(bold=True)
# params block D2:H9
we['D2']='Selected model'; we['D2'].font=f_(bold=True)
for j,t in enumerate(['b0 / b','temp','wbal','hot'],5): we.cell(2,j-0,t) if False else None
hdr(we,2,['','b0','temp','water bal','hot days'],col=4)
def prm(row,label,cols):
    we.cell(row,4,label).font=f_(bold=True)
    for j,col in enumerate(cols): 
        if col: c=we.cell(row,5+j,f'=IFERROR(INDEX(Model!${col}$2:${col}${NM},$B$8),NA())'); c.number_format='0.000'
prm(3,'coefficient',['B','C','D','E']); prm(4,'training mean',[None,'F','G','H']); prm(5,'training sd',[None,'I','J','K'])
prm(6,'training min',[None,'M','N','O']); prm(7,'training max',[None,'P','Q','R'])
we['D8']='smear'; we['E8']=f'=IFERROR(INDEX(Model!$L$2:$L${NM},$B$8),NA())'; we['D9']='baseline t/ha'; we['E9']=f'=IFERROR(INDEX(Model!$V$2:$V${NM},$B$8),NA())'
we['E8'].number_format='0.000'; we['E9'].number_format='0.00'
for r in (8,9): we.cell(r,4).font=f_(bold=True)
# table
T0=13
hdr(we,T0-1,['Year','ssp126 (low)','ssp245 (mid)','ssp585 (high)','Baseline 2012–26','ssp126 flag','ssp245 flag','ssp585 flag'])
hdr(we,T0-2,['','Yield t/ha','','','','Outside training weather?','',''])
sc=['ssp126','ssp245','ssp585']; hc=[10,13,16]  # helper start cols J,M,P
hdr(we,T0-1,['T126','W126','H126','T245','W245','H245','T585','W585','H585'],col=10)
we.cell(T0-2,10,'Helper: adjusted growing-season features').font=f_(italic=True,color='595959')
for i,y in enumerate(range(2027,2061)):
    r=T0+i; we.cell(r,1,y)
    for s,(name,c0) in enumerate(zip(sc,hc)):
        k=f'$B$3&"|{name}|"&$A{r}'; m_=f'MATCH({k},Features!$A$2:$A${NF},0)'
        we.cell(r,c0,f'=IFERROR(INDEX(Features!$E$2:$E${NF},{m_})+$B$5,NA())').number_format='0.00'
        we.cell(r,c0+1,f'=IFERROR(INDEX(Features!$F$2:$F${NF},{m_})+INDEX(Features!$H$2:$H${NF},{m_})*$B$6/100,NA())').number_format='0'
        we.cell(r,c0+2,f'=IFERROR(INDEX(Features!$G$2:$G${NF},{m_}),NA())').number_format='0.0'
        T,W,H=L(c0),L(c0+1),L(c0+2)
        c=we.cell(r,2+s,f'=EXP($E$3+$F$3*({T}{r}-$F$4)/$F$5+$G$3*({W}{r}-$G$4)/$G$5+$H$3*({H}{r}-$H$4)/$H$5)*$E$8'); c.number_format='0.00'
        we.cell(r,6+s,f'=IF(ISNA(B{r}),"",IF(OR({T}{r}<$F$6-0.5,{T}{r}>$F$7+0.5,{W}{r}<$G$6,{W}{r}>$G$7,{H}{r}<$H$6,{H}{r}>$H$7),"extrapolated",""))')
    we.cell(r,5,'=$E$9').number_format='0.00'
TN=T0+33
ch=LineChart(); ch.title='Yield t/ha, 2027–2060'; ch.height=9; ch.width=20; ch.y_axis.title='t/ha'; ch.x_axis.title='Year'
ch.add_data(Reference(we,min_col=2,max_col=5,min_row=T0-1,max_row=TN),titles_from_data=True)
ch.set_categories(Reference(we,min_col=1,min_row=T0,max_row=TN))
cols_=['3B8EA5','E0A526','C4452F','7F7F7F']
for s,cc in zip(ch.series,cols_): s.graphicalProperties.line.solidFill=cc; s.graphicalProperties.line.width=22000; s.smooth=False
ch.series[3].graphicalProperties.line.dashStyle='dash'
ch.x_axis.delete=False; ch.y_axis.delete=False
we.add_chart(ch,'J2')
for i,w in enumerate([24,16,14,14,16,13,13,13,3,9,9,9,9,9,9,9,9,9],1): we.column_dimensions[L(i)].width=w
we.row_dimensions[T0-1].height=30; we.freeze_panes=None
# ---------- Summary ----------
ws=wb.create_sheet('Summary',0)
ws['A1']='Crop yield outlook under climate scenarios'; ws['A1'].font=f_(bold=True,size=14)
ws['A2']='Mean yield (t/ha) over the chosen period vs the 2012–2026 baseline. Yields only, no prices.'; ws['A2'].font=f_(italic=True,color='595959')
for r,(lab,val) in enumerate([('Period start year',2051),('Period end year',2060)],3):
    ws.cell(r,1,lab).font=f_(bold=True); c=ws.cell(r,2,val); c.font=f_(color='0000FF',bold=True); c.fill=INP; c.border=BOX
dv=DataValidation(type='whole',operator='between',formula1='2027',formula2='2060'); ws.add_data_validation(dv); dv.add('B3:B4')
hdr(ws,6,['Region','Crop','Baseline 2012–26 (t/ha)','ssp126 yield','ssp245 yield','ssp585 yield','ssp126 change','ssp245 change','ssp585 change','ssp126 extrapolated','ssp245 extrapolated','ssp585 extrapolated'])
ws.row_dimensions[6].height=44
rows=[('FI_SW','pea'),('FI_SW','turnip_rape'),('FI_SW','carrot'),('FI_SW','potato'),('FI_SW','spinach'),('SE_SKANE','pea')]
R=f'Projections!$A$2:$A${NP}'
def av(col,r,s): return f'AVERAGEIFS(Projections!${col}$2:${col}${NP},{R},$A{r},Projections!$B$2:$B${NP},$B{r},Projections!$C$2:$C${NP},"{s}",Projections!$D$2:$D${NP},">="&$B$3,Projections!$D$2:$D${NP},"<="&$B$4)'
for i,(rg,cp) in enumerate(rows,7):
    ws.cell(i,1,rg); ws.cell(i,2,cp)
    ws.cell(i,3,f'=AVERAGEIFS(Projections!$F$2:$F${NP},{R},$A{i},Projections!$B$2:$B${NP},$B{i})').number_format='0.00'
    for s,name in enumerate(sc):
        ws.cell(i,4+s,'='+av('E',i,name)).number_format='0.00'
        ws.cell(i,7+s,f'={L(4+s)}{i}/$C{i}-1').number_format='+0.0%;-0.0%;0.0%'
        ws.cell(i,10+s,'='+av('H',i,name)).number_format='0%'
ws.conditional_formatting.add('G7:I12',ColorScaleRule(start_type='num',start_value=-0.25,start_color='E8806C',mid_type='num',mid_value=0,mid_color='FFFFFF',end_type='num',end_value=0.15,end_color='7CC49A'))
ws['A14']='Reading the table'; ws['A14'].font=f_(bold=True,size=11)
msgs=['Defaults show 2051–2060 (written for that period). “Extrapolated” = share of those years whose weather is outside what the model saw in 2012–2026: treat those as direction, not forecast.',
'Finland: limited warming (ssp126) lifts pea and turnip rape yields slightly; high warming (ssp585) cuts both by roughly 14–15% by the 2050s.',
'Carrot is the most exposed Finnish crop under high warming (about −21%); potato is less exposed (about −5%). Spinach shows no weather response in the data.',
'Skåne pea: only 9 seasons of data and weather explains none of it in backtests – scenario differences there are NOT reliable.',
'New crops for Finland cannot be forecast – there is no yield data for them. See About for what would be needed.']
for i,m in enumerate(msgs,15):
    ws.cell(i,1,m).alignment=Alignment(wrap_text=True,vertical='top'); ws.merge_cells(start_row=i,start_column=1,end_row=i,end_column=12); ws.row_dimensions[i].height=30
for i,w in enumerate([14,13,16,12,12,12,12,12,12,13,13,13],1): ws.column_dimensions[L(i)].width=w
# ---------- Data_checks ----------
wd=wb.create_sheet('Data_checks')
hdr(wd,1,['Source','Check','Result','Action'])
log=json.load(open(f'{O}/data_quality_log.json'))
for lv,msg in log: wd.append(['Automatic (pipeline log)',lv,msg,'Logged by yield_pipeline.py'])
chk=[('Farm survey','Implausible yields (>3× or <0.3× crop median, likely unit errors)','6 pea, 3 potato, 10 turnip rape','Excluded from training (19 of 3,437 rows)'),
('Farm survey','Nitrogen above 400 kg/ha','11 rows','Flagged; not used by the model'),
('Foodhills (Skåne pea)','Missing values, duplicates, implausible yields','None found (2,683 rows, 2018–2026)','Used as is'),
('Foodhills (Skåne pea)','Seasons available for learning a weather response','Only 9','Warning: backtest R² below 0, scenario differences unreliable'),
('Weather (monthly)','Missing values, negative rainfall, impossible temperatures','None found','–'),
('Weather (monthly)','Cell-to-region mapping','Cell prefix GF→Finland SW, GS→Skåne (assumed; no lookup provided)','Cells averaged within region'),
('C1 plan','Yield file crop equals planned crop','100% match','–'),
('Model','Spinach: weather explains nothing in backtest','R² below 0','Warning: spinach differences ≈ 0'),
('Model','Future weather outside 2012–2026 range','Up to 90% of 2050s years under ssp585 (Finland)','Flagged as “extrapolated” in every output'),
('Not used','Daily weather (parquet) and farm soil/irrigation detail','Not read in this version','Would improve fit; see About')]
for r in chk: wd.append(list(r))
for i,w in enumerate([24,60,48,52],1): wd.column_dimensions[L(i)].width=w
for rr in wd.iter_rows(min_row=2):
    for c in rr: c.alignment=Alignment(wrap_text=True,vertical='top')
# ---------- About ----------
wa=wb.create_sheet('About')
txt=[('What this is',True),('A scenario workbook for management: how crop yields (t/ha) may change in Finland and southern Sweden under three climate scenarios (SSP1-2.6 low, SSP2-4.5 middle, SSP5-8.5 high), 2027–2060. Yields only – no prices or profit.',False),
('How to use',True),('Summary: pick a period (yellow cells) and read the table. Explorer: pick region, crop, extra warming and rainfall change (yellow cells) to see yearly yields and a chart. Projections: flat table, ready for PivotTables. Data_checks: every data problem the pipeline found is listed automatically. ',False),
('Colour code',True),('Blue text on yellow = input you may change. Black = formula.',False),
('Method',True),('One model per region and crop, trained on 2012–2026 survey yields (Finland: farm survey; Skåne: Foodhills pea deliveries) and May–September weather: mean temperature, water balance (precipitation − evaporation demand) and hot days. Outliers were removed first (see Data_checks). The Model sheet holds every coefficient, so every number can be reproduced by hand.',False),
('Limits',True),('1) Weather explains only part of yield variation (backtest R² about 0.2–0.3). 2) 2050s weather under high warming is mostly outside the training range: direction only. 3) The extra-warming slider shifts temperature only; hot days and water balance (from evaporation) do not respond to it. 4) No adaptation, new varieties, CO₂ effect or heat-damage thresholds. 5) Skåne pea and spinach: weather response not identified. 6) The region mapping of weather cells (GF/GS prefixes) is an assumption.',False),
('New crops',True),('The data contains no yield records for crops not already grown, so none can be forecast. Southwest Finland in the 2050s under ssp245 has a growing season (15.5 °C) close to Skåne today (15.6 °C); under ssp585 (17.0 °C) it is warmer than Skåne today. Yield data from warmer regions (Skåne, Denmark) for candidate crops would let us test them.',False),
('Source of numbers',True),('Farm survey, Foodhills data, weather files and crop plan provided for this task (synthetic data).',False)]
for i,(t,b) in enumerate(txt,1):
    c=wa.cell(i,1,t); c.font=f_(bold=b,size=11 if b else 10); c.alignment=Alignment(wrap_text=True,vertical='top')
    if not b: wa.row_dimensions[i].height=max(30,15*(len(t)//110+1))
wa.column_dimensions['A'].width=120
# order & fonts
wb._sheets=[wb['Summary'],wb['Explorer'],wb['Projections'],wb['Data_checks'],wb['About'],wb['Model'],wb['Features']]
for s in wb: style_all(s)
wb.save(f'{O}/Crop_climate_scenarios.xlsx')
print('saved',NP,NF,NM)
