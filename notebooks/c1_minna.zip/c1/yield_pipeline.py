"""Yield pipeline: cleans survey, trains per-crop weather model, writes model.json + filled C1 submission.
Usage: python yield_pipeline.py <dir with the 4 csv files> <output dir>"""
import sys, json, numpy as np, pandas as pd
src, out = (sys.argv + ['/mnt/user-data/uploads', '/mnt/user-data/outputs'][len(sys.argv)-1:])[1:3]
ERR = []; LOG = []
def err(m): ERR.append(m); LOG.append(['ERROR', m]); print('DATA ERROR:', m)
def warn(m): LOG.append(['WARNING', m]); print('WARNING:', m)

w = pd.read_csv(f'{src}/weather_monthly_1991_2060.csv')
s = pd.read_csv(f'{src}/farm_survey_fi.csv')
c1 = pd.read_csv(f'{src}/C1_yields_2027_2031_submission.csv')
plan = pd.read_csv(f'{src}/parcel_crop_history_and_plan.csv')

# ---- weather checks / region features (growing season May-Sep) ----
for col in ['tmean_c','precip_mm','pet_mm','hot_days_tmax_ge_27']:
    n = w[col].isna().sum()
    if n: err(f'weather: {n} missing values in {col}')
if (w.precip_mm < 0).any(): err('weather: negative precipitation')
if not w.tmean_c.between(-45, 40).all(): err('weather: tmean_c outside -45..40 C')
w['region'] = w.cell_id.str[:2].map({'GF': 'FI_SW', 'GS': 'SE_SKANE'})
if w.region.isna().any(): err('weather: cell_id prefixes not GF/GS - cannot map to region')
g = w[w.month.between(5, 9)].groupby(['region','scenario','year','cell_id']).agg(
    tmean=('tmean_c','mean'), precip=('precip_mm','sum'), pet=('pet_mm','sum'), hot=('hot_days_tmax_ge_27','sum')).reset_index()
g['wbal'] = g.precip - g.pet
F = g.groupby(['region','scenario','year'], as_index=False)[['tmean','precip','wbal','hot']].mean()
FEATS = ['tmean','wbal','hot']

# ---- survey cleaning ----
n0 = len(s)
if s.duplicated('survey_id').any(): err(f'survey: {s.duplicated("survey_id").sum()} duplicate survey_id')
if s.yield_t_ha.isna().any(): err('survey: missing yields')
med = s.groupby('crop').yield_t_ha.transform('median')
bad = (s.yield_t_ha > 3*med) | (s.yield_t_ha < 0.3*med)
for crop, k in s[bad].groupby('crop').size().items():
    err(f'survey: {k} implausible {crop} yields (>3x or <0.3x crop median, e.g. unit errors) - excluded')
if (s.n_mineral_kg_ha > 400).any(): warn(f'survey: {(s.n_mineral_kg_ha>400).sum()} rows with N > 400 kg/ha (input not used by model)')
s = s[~bad]
print(f'survey rows used: {len(s)} of {n0}')

# ---- Foodhills (Skane pea) ----
fh = pd.read_csv(f'{src}/foodhills_odlingsdata_se.csv', sep=';', decimal=',')
fh.columns = ['farm_id','year','crop','area_ha','delivered_t','n_kg_ha','diesel_l_ha','irrigated']
if fh.isna().any().any(): err('foodhills: missing values')
if fh.duplicated(['farm_id','year']).any(): err('foodhills: duplicate farm/year rows')
if (fh.area_ha <= 0).any(): err('foodhills: non-positive area')
fh['yield_t_ha'] = fh.delivered_t / fh.area_ha
fm = fh.yield_t_ha.median(); fb = (fh.yield_t_ha > 3*fm) | (fh.yield_t_ha < 0.3*fm)
if fb.any(): err(f'foodhills: {fb.sum()} implausible yields - excluded')
fh = fh[~fb].assign(crop='pea', region='SE_SKANE')
print(f'foodhills rows used: {len(fh)} (years {fh.year.min()}-{fh.year.max()})')
s = s.assign(region='FI_SW')

# ---- model per region x crop: ridge on log yield, leave-one-year-out CV ----
tr = pd.concat([s[['region','crop','year','farm_id','yield_t_ha']], fh[['region','crop','year','farm_id','yield_t_ha']]])
d = tr.merge(F[F.scenario=='historical'][['region','year']+FEATS], on=['region','year'], how='left')
farm_eff = {}  # shrunk farm effect on log yield (backtest: lifts C1-style score ~50 -> ~57)
if d[FEATS].isna().any().any(): err('training years without historical weather')
def ridge(X, y, a):
    A = X.T @ X + a*np.eye(X.shape[1]); return np.linalg.solve(A, X.T @ (y - y.mean())), y.mean()
model = {}
for (reg, crop), dc in d.groupby(['region','crop']):
    mu, sd = dc[FEATS].mean().values, dc[FEATS].std().values
    X = (dc[FEATS].values - mu) / sd; y = np.log(dc.yield_t_ha.values); yrs = dc.year.values
    best = None
    for a_ in [1, 30, 300, 3000]:
        pr = np.zeros(len(y))
        for yr in np.unique(yrs):
            m = yrs == yr; b, b0 = ridge(X[~m], y[~m], a_); pr[m] = b0 + X[m] @ b
        r2 = 1 - ((y-pr)**2).sum() / ((y-y.mean())**2).sum()
        if best is None or r2 > best[0]: best = (r2, a_)
    b, b0 = ridge(X, y, best[1]); res = y - (b0 + X @ b)
    k = f'{reg}|{crop}'
    rr = pd.Series(res, index=dc.index).groupby(dc.farm_id.values).agg(['sum','count'])
    farm_eff[k] = (rr['sum'] / (rr['count'] + 2.0)).to_dict()
    model[k] = dict(b0=float(b0), b=b.tolist(), mu=mu.tolist(), sd=sd.tolist(), smear=float(np.exp(res.var()/2)),
                    lo=dc[FEATS].min().tolist(), hi=dc[FEATS].max().tolist(), cv_r2=float(best[0]), n=int(len(y)), years=int(len(np.unique(yrs))))
    print(f'{k}: n={len(y)} years={len(np.unique(yrs))} leave-year-out R2 (log yield)={best[0]:.3f} alpha={best[1]}')
    if best[0] < 0.02: warn(f'{k}: weather explains almost no yield variance - scenario differences will be small')
    if len(np.unique(yrs)) < 12: warn(f'{k}: only {len(np.unique(yrs))} distinct seasons of training data - weather response is weakly identified')

def predict(k, f):
    m = model[k]; z = (np.array(f) - m['mu']) / m['sd']
    return float(np.exp(m['b0'] + z @ np.array(m['b'])) * m['smear'])

# ---- scenario features table + planned area ----
fut = F[(F.scenario != 'historical') & F.year.between(2027, 2060)]  # tool uses to 2060; C1 uses 2027-31
key = ['farm_id','parcel_id','year']
if c1.duplicated(key).any(): err('C1: duplicate farm/parcel/year keys')
pl = plan[plan.status == 'planned']
mm = c1.merge(pl[key+['crop']], on=key, how='left', suffixes=('','_plan'))
if mm.crop_plan.isna().any(): err(f'C1: {mm.crop_plan.isna().sum()} rows have no planned entry')
if (mm.crop != mm.crop_plan).any(): err('C1: crop differs from plan')
for (r_, cp) in set(zip(c1.region, c1.crop)):
    if f'{r_}|{cp}' not in model: err(f'C1: {r_}/{cp} has no yield data - no model')
area = c1.groupby(['region','crop','year']).area_ha.sum().reset_index()

rows = []
for _, r in fut.iterrows():
    for cp in set(c1[c1.region == r.region].crop):
        k = f'{r.region}|{cp}'
        if k not in model: continue
        rows.append(dict(region=r.region, scenario=r.scenario, year=int(r.year), crop=cp, f=[r[q] for q in FEATS], precip=float(r.precip), yield_t_ha=predict(k, [r[q] for q in FEATS])))
hf = F[(F.scenario=='historical')&(F.year>=2012)]
base = {k: float(np.mean([predict(k,[x[q] for q in FEATS]) for _, x in hf[hf.region==k.split('|')[0]].iterrows()])) for k in model}
json.dump(dict(feats=FEATS, model=model, rows=rows, area=area.to_dict('records'), hist_baseline=base), open(f'{out}/model.json','w'))

# ---- fill C1: scenario-specific columns + mean across scenarios ----
P = pd.DataFrame(rows).pivot_table(index=['region','crop','year'], columns='scenario', values='yield_t_ha').reset_index()
P = P  # all years kept; merge on year picks 2027-31
sub = c1.drop(columns='yield_t_ha_pred').merge(P, on=['region','crop','year'], how='left')
sub['farm_effect'] = [np.exp(farm_eff.get(f'{r}|{c}', {}).get(f, 0.0)) for r, c, f in zip(sub.region, sub.crop, sub.farm_id)]
sub['yield_t_ha_pred'] = (sub['ssp245'] * sub['farm_effect']).round(3)  # C1 weather is a single SSP2-4.5 realisation
if sub.yield_t_ha_pred.isna().any(): err('C1: unpredicted rows')
sub.to_csv(f'{out}/C1_yields_2027_2031_filled.csv', index=False)
json.dump(LOG, open(f'{out}/data_quality_log.json','w'), ensure_ascii=False, indent=1)
print(f'errors found: {len(ERR)}'); print(sub.groupby(['region','crop'])[['ssp126','ssp245','ssp585']].mean().round(2))
