This folder contains additional material about C1 scenario. 
- The requested C1_submission.csv with the yield_t_ha_pred column filled.
- The yield_pipeline.py which explains how the yield t/ha values were calculated. 
- A workbook for Excel (the format Apetit representatives are most familiar with)
- The build_workbook.py file which explains how the workbook was compiled. 
- An interactive html file for demonstrating data visualisation.   

AIs: Claude and Gemini. 